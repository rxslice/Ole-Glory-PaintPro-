# 🚀 Ole Glory PaintPro - Deployment Guide

## Complete APK Build & Distribution Instructions

---

## 📋 Prerequisites Checklist

### 1. Install Flutter SDK

**Windows**:
```powershell
# Download from: https://docs.flutter.dev/get-started/install/windows
# Extract to C:\src\flutter
# Add to PATH: C:\src\flutter\bin
```

**macOS**:
```bash
# Download from: https://docs.flutter.dev/get-started/install/macos
cd ~/development
unzip ~/Downloads/flutter_macos_*.zip
echo 'export PATH="$PATH:$HOME/development/flutter/bin"' >> ~/.zshrc
source ~/.zshrc
```

**Linux**:
```bash
cd ~/development
tar xf ~/Downloads/flutter_linux_*.tar.xz
echo 'export PATH="$PATH:$HOME/development/flutter/bin"' >> ~/.bashrc
source ~/.bashrc
```

### 2. Verify Installation

```bash
flutter doctor

# You should see:
# [✓] Flutter (Channel stable, 3.x.x)
# [✓] Android toolchain - develop for Android devices
# [✓] Android Studio (optional but recommended)
```

### 3. Accept Android Licenses

```bash
flutter doctor --android-licenses
# Type 'y' to accept all licenses
```

---

## 🔨 Building the APK

### Method 1: Automated Script (Recommended)

```bash
cd ole_glory_paintpro
./build.sh
```

The script will:
1. ✅ Check Flutter installation
2. ✅ Clean previous builds
3. ✅ Install dependencies
4. ✅ Build release APK
5. ✅ Show APK location and size

### Method 2: Manual Build

```bash
cd ole_glory_paintpro

# Step 1: Clean
flutter clean

# Step 2: Get dependencies
flutter pub get

# Step 3: Build APK
flutter build apk --release

# Output: build/app/outputs/flutter-apk/app-release.apk
```

### Method 3: Optimized Builds

**For 64-bit devices only** (smaller file):
```bash
flutter build apk --release --target-platform android-arm64
```

**For 32-bit devices only**:
```bash
flutter build apk --release --target-platform android-arm
```

**Split APKs** (smallest, per architecture):
```bash
flutter build apk --release --split-per-abi
# Creates: app-arm64-v8a-release.apk, app-armeabi-v7a-release.apk, app-x86_64-release.apk
```

---

## 📱 Installing on Android Device

### Option A: Direct USB Installation

1. **Enable USB Debugging** on your phone:
   - Settings → About Phone
   - Tap "Build Number" 7 times
   - Go back → Developer Options
   - Enable "USB Debugging"

2. **Connect phone via USB**

3. **Install**:
```bash
# Automatic (phone will prompt)
flutter install

# OR manual
adb install build/app/outputs/flutter-apk/app-release.apk
```

### Option B: Transfer and Install

1. **Copy APK to phone**:
   - Via USB: Copy to Downloads folder
   - Via cloud: Upload to Drive/Dropbox, download on phone
   - Via email: Email to yourself, download on phone

2. **On phone**:
   - Open Files/Downloads app
   - Tap `app-release.apk`
   - If prompted: Settings → Allow "Install from unknown sources"
   - Tap "Install"
   - Tap "Open"

### Option C: Wireless Installation

```bash
# Connect phone and computer to same WiFi
# On phone: Enable "Wireless debugging" in Developer Options

# On computer:
adb connect PHONE_IP:PORT
adb install build/app/outputs/flutter-apk/app-release.apk
```

---

## 📦 Distribution Methods

### 1. Internal Company Use

**Best for**: Teams, contractors, employees

**Steps**:
1. Build APK (steps above)
2. Upload to:
   - Company server
   - Google Drive / Dropbox / OneDrive
   - Internal file sharing system
3. Share link with team
4. Users download and install

**Pros**: Free, no approval process, instant updates  
**Cons**: Users must enable "unknown sources"

### 2. Google Play Store (Public)

**Best for**: Wide distribution, credibility, updates

**Steps**:
1. Create Google Play Console account ($25 one-time fee)
2. Create app listing (name, description, screenshots)
3. Build signed App Bundle:
   ```bash
   # Generate signing key (first time only)
   keytool -genkey -v -keystore ~/ole-glory-key.jks \
     -keyalg RSA -keysize 2048 -validity 10000 \
     -alias oleglory
   
   # Configure android/app/build.gradle with signing
   # Then build:
   flutter build appbundle --release
   ```
4. Upload `app-release.aab` to Play Console
5. Submit for review (1-3 days)

**Pros**: Automatic updates, no "unknown sources", credible  
**Cons**: $25 fee, review process, policy compliance

### 3. Alternative App Stores

- **Amazon Appstore**: Free, easier approval
- **Samsung Galaxy Store**: For Samsung devices
- **F-Droid**: For open-source apps
- **APKPure, Aptoide**: Third-party stores

### 4. Direct Website Download

**Best for**: Your own website, landing page

1. Host APK on your web server
2. Create download page with instructions
3. Add QR code for easy mobile download
4. Include security note: "Official download from [your domain]"

---

## 🔐 Code Signing (For Production)

### Why Sign?

- **Verification**: Proves you're the real developer
- **Updates**: Only signed updates will install over existing app
- **Play Store**: Required for Google Play

### Generate Signing Key

```bash
# Create keystore
keytool -genkey -v -keystore ~/ole-glory-release.jks \
  -alias oleglory -keyalg RSA -keysize 2048 -validity 10000

# Enter strong password (save it!)
# Enter your details (name, company, etc.)
```

### Configure Signing

1. Create `android/key.properties`:
```properties
storePassword=YOUR_STORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=oleglory
storeFile=/path/to/ole-glory-release.jks
```

2. Update `android/app/build.gradle`:
```gradle
// Add before android block
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    // ...
    
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
    
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

3. Build signed APK:
```bash
flutter build apk --release
# Now signed with your key!
```

**⚠️ IMPORTANT**: 
- **Backup your keystore file** - if lost, you can't update your app!
- **Never commit key.properties** to version control
- **Store password securely** - use password manager

---

## 🧪 Testing Before Distribution

### 1. Debug Testing

```bash
# Install debug version
flutter run

# Hot reload on changes
# Press 'r' in terminal
```

### 2. Release Testing

```bash
# Build and install release APK
flutter build apk --release
adb install build/app/outputs/flutter-apk/app-release.apk
```

### 3. Test Checklist

- [ ] All buttons respond immediately
- [ ] Add/delete rooms works
- [ ] Calculations are accurate
- [ ] Save/load projects works
- [ ] Export/share functions work
- [ ] Notes save properly
- [ ] Dark mode toggles correctly
- [ ] App doesn't crash on:
  - [ ] Rotation
  - [ ] Background/foreground
  - [ ] Low memory
  - [ ] Invalid inputs

### 4. Device Testing

Test on:
- [ ] Different screen sizes (phone, tablet)
- [ ] Different Android versions (5.0, 10, 13, 14)
- [ ] Different manufacturers (Samsung, Google, Xiaomi)

---

## 📊 APK Size Optimization

### Current Size: ~20-25 MB

**To reduce**:

1. **Split APKs by architecture**:
```bash
flutter build apk --split-per-abi
# Creates ~8-10 MB APKs per architecture
```

2. **Remove unused resources**:
```bash
flutter build apk --release --target-platform android-arm64
```

3. **Use App Bundle** (Play Store):
```bash
flutter build appbundle --release
# Play Store delivers optimized APK per device (~6-8 MB)
```

---

## 🔄 Updating the App

### Version Management

1. Update `pubspec.yaml`:
```yaml
version: 1.0.1+2  # Format: version_name+build_number
```

2. Rebuild:
```bash
flutter build apk --release
```

3. Users install new APK over old one (if signed with same key)

### Auto-update Solutions

For non-Play Store:
- **Firebase App Distribution**: Push updates to testers
- **CodePush**: Over-the-air updates
- **Custom**: Check version on app start, prompt download

For Play Store:
- Automatic updates (default)
- Users control in Play Store settings

---

## 🐛 Troubleshooting

### "Flutter not found"
```bash
# Add to PATH
export PATH="$PATH:/path/to/flutter/bin"
flutter doctor
```

### "Gradle build failed"
```bash
# Clear Gradle cache
cd android
./gradlew clean
cd ..
flutter clean
flutter pub get
flutter build apk --release
```

### "Execution failed for task ':app:lintVitalRelease'"
```bash
# Add to android/app/build.gradle
android {
    lintOptions {
        checkReleaseBuilds false
    }
}
```

### "App installs but doesn't open"
```bash
# Check logs
adb logcat | grep -i flutter

# Reinstall
adb uninstall com.oleglory.paintpro
flutter install
```

### "Install blocked"
- Settings → Security
- Enable "Install unknown apps" for your browser/file manager

---

## 📈 Analytics & Monitoring (Optional)

Add if needed:

1. **Firebase Crashlytics**: Track crashes
2. **Firebase Analytics**: Usage statistics
3. **Sentry**: Error monitoring
4. **Google Analytics**: User behavior

```bash
flutter pub add firebase_core firebase_crashlytics firebase_analytics
```

---

## ✅ Production Checklist

Before wide distribution:

- [ ] App tested on multiple devices
- [ ] All features work correctly
- [ ] No crashes or bugs
- [ ] Code signed with production key
- [ ] Keystore backed up securely
- [ ] Version number updated
- [ ] APK tested on clean device
- [ ] Screenshots prepared
- [ ] App description written
- [ ] Privacy policy created (if collecting data)
- [ ] Distribution method chosen
- [ ] Support contact added

---

## 🎯 Success Metrics

After deployment, monitor:

- **Install rate**: Downloads / Link shares
- **Retention**: Users still using after 7/30 days
- **Crash rate**: Should be < 1%
- **Ratings**: Target 4.5+ stars
- **Support requests**: Common issues?

---

## 🚀 You're Ready!

You now have everything to:

1. ✅ Build production APK
2. ✅ Test thoroughly
3. ✅ Sign for updates
4. ✅ Distribute to users
5. ✅ Monitor and update

**The app is production-ready** - deploy with confidence!

---

## 📞 Support

For Flutter issues: https://docs.flutter.dev/  
For Android issues: https://developer.android.com/

**Your app is ready for prime time!** 🎉
