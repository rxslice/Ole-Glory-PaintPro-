import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:share_plus/share_plus.dart';
import 'package:intl/intl.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

void main() {
  runApp(const OleGloryPaintProApp());
}

class OleGloryPaintProApp extends StatelessWidget {
  const OleGloryPaintProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ole Glory PaintPro',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF153EFF),
          brightness: Brightness.light,
        ),
        fontFamily: 'Roboto',
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF153EFF),
          brightness: Brightness.dark,
        ),
        fontFamily: 'Roboto',
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  Project currentProject = Project.newProject();
  List<Project> savedProjects = [];
  CalculationResults? results;
  bool isDarkMode = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadProjects();
  }

  Future<void> _loadProjects() async {
    final prefs = await SharedPreferences.getInstance();
    final String? projectsJson = prefs.getString('oleglory_v2_projects');
    if (projectsJson != null) {
      final List<dynamic> decoded = json.decode(projectsJson);
      setState(() {
        savedProjects = decoded.map((e) => Project.fromJson(e)).toList();
      });
    }
  }

  Future<void> _saveProjects() async {
    final prefs = await SharedPreferences.getInstance();
    final String encoded = json.encode(savedProjects.map((e) => e.toJson()).toList());
    await prefs.setString('oleglory_v2_projects', encoded);
  }

  void _saveCurrentProject() {
    final index = savedProjects.indexWhere((p) => p.id == currentProject.id);
    if (index >= 0) {
      savedProjects[index] = currentProject.copy();
    } else {
      savedProjects.add(currentProject.copy());
    }
    _saveProjects();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('✓ Project saved'), duration: Duration(seconds: 2)),
    );
    setState(() {});
  }

  void _calculateEstimate() {
    setState(() {
      results = Calculator.calculate(currentProject);
      _tabController.animateTo(1);
    });
  }

  void _loadProject(Project project) {
    setState(() {
      currentProject = project.copy();
      _tabController.animateTo(0);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('✓ Project loaded'), duration: Duration(seconds: 2)),
    );
  }

  void _deleteProject(String id) {
    setState(() {
      savedProjects.removeWhere((p) => p.id == id);
      _saveProjects();
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isDarkMode
                ? [const Color(0xFF0b1220), const Color(0xFF081124)]
                : [const Color(0xFFEBF4FF), const Color(0xFFE0E7FF), const Color(0xFFF3E8FF)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(theme),
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _buildCalculateTab(),
                    _buildResultsTab(),
                    _buildSavedTab(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: _buildActionButtons(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }

  Widget _buildHeader(ThemeData theme) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [Color(0xFF153EFF), Color(0xFF6A3AF2), Color(0xFF8B4CF0)],
        ),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.format_paint, color: Colors.white, size: 32),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Estimator', style: TextStyle(color: Colors.white70, fontSize: 12)),
                    Text('Ole Glory PaintPro',
                        style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
              IconButton(
                onPressed: () {
                  setState(() {
                    isDarkMode = !isDarkMode;
                  });
                },
                icon: Icon(isDarkMode ? Icons.light_mode : Icons.dark_mode, color: Colors.white),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
            ),
            child: TabBar(
              controller: _tabController,
              indicator: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              dividerColor: Colors.transparent,
              labelColor: const Color(0xFF6A3AF2),
              unselectedLabelColor: Colors.white.withOpacity(0.9),
              labelStyle: const TextStyle(fontWeight: FontWeight.bold),
              tabs: [
                const Tab(text: 'Calculate'),
                const Tab(text: 'Results'),
                Tab(text: 'Saved (${savedProjects.length})'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCalculateTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildCard(
            child: Column(
              children: [
                _buildTextField(
                  label: 'Client Name',
                  hint: 'Optional - Client or company',
                  value: currentProject.clientName,
                  onChanged: (v) => setState(() => currentProject.clientName = v),
                ),
                const SizedBox(height: 12),
                _buildTextField(
                  label: 'Project Address',
                  hint: 'Optional - Address or job site',
                  value: currentProject.projectAddress,
                  onChanged: (v) => setState(() => currentProject.projectAddress = v),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _buildCard(
            title: 'Paint Settings',
            icon: Icons.settings,
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: _buildNumberField(
                        label: 'Coverage (sq ft/gal)',
                        value: currentProject.coverage.toString(),
                        onChanged: (v) => setState(() => currentProject.coverage = double.tryParse(v) ?? 350),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildDropdown(
                        label: 'Surface Type',
                        value: currentProject.surfaceType,
                        items: const ['smooth', 'semi-smooth', 'textured', 'rough'],
                        onChanged: (v) => setState(() => currentProject.surfaceType = v!),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _buildCard(
            title: 'Pricing',
            icon: Icons.attach_money,
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: _buildNumberField(
                        label: 'Paint Price (\$/gal)',
                        value: currentProject.paintPrice?.toString() ?? '',
                        onChanged: (v) => setState(() => currentProject.paintPrice = double.tryParse(v)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildNumberField(
                        label: 'Labor Rate (\$/hr)',
                        value: currentProject.laborRate?.toString() ?? '',
                        onChanged: (v) => setState(() => currentProject.laborRate = double.tryParse(v)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                _buildNumberField(
                  label: 'Price per Sq Ft (\$)',
                  value: currentProject.pricePerSqFt?.toString() ?? '',
                  onChanged: (v) => setState(() => currentProject.pricePerSqFt = double.tryParse(v)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          ...currentProject.rooms.map((room) => _buildRoomCard(room)),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: currentProject.rooms.length < 10
                ? () {
                    setState(() {
                      currentProject.addRoom();
                    });
                  }
                : null,
            icon: const Icon(Icons.add),
            label: Text('Add Room (${currentProject.rooms.length}/10)'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF0ea5d8),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              minimumSize: const Size(double.infinity, 50),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: _calculateEstimate,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF3B82F6),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('Calculate Estimate', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: _saveCurrentProject,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF8B5CF6),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('Save', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 100),
        ],
      ),
    );
  }

  Widget _buildResultsTab() {
    if (results == null) {
      return const Center(child: Text('Run a calculation first'));
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildResultCard(
            title: 'Paint Totals',
            mainText: '${results!.gallons} gal • ${results!.totalPaint.toStringAsFixed(2)} needed',
            summary: '${results!.totalArea.toStringAsFixed(1)} ft²',
            color: Colors.blue,
            details: '''• Total paintable area: ${results!.totalArea.toStringAsFixed(1)} sq ft
• Paint required: ${results!.totalPaint.toStringAsFixed(2)} gal (≈ ${results!.gallons} gal / ${results!.quarts} qts / ${results!.liters.toStringAsFixed(2)} L)
${results!.paintCost != null ? '• Paint cost: \$${results!.paintCost!.toStringAsFixed(2)}' : ''}''',
          ),
          const SizedBox(height: 16),
          _buildResultCard(
            title: 'Labor & Time',
            mainText: '${results!.laborHours.toStringAsFixed(1)} hrs',
            summary: results!.laborCost != null ? '\$${results!.laborCost!.toStringAsFixed(2)}' : '—',
            color: Colors.green,
            details: '''• Estimated labor hours: ${results!.laborHours.toStringAsFixed(1)} hrs
${results!.laborCost != null ? '• Labor cost: \$${results!.laborCost!.toStringAsFixed(2)}' : ''}''',
          ),
          const SizedBox(height: 16),
          _buildResultCard(
            title: 'Total Summary',
            mainText: results!.totalCost != null ? '\$${results!.totalCost!.toStringAsFixed(2)}' : 'Estimate',
            summary: '',
            color: Colors.purple,
            details: _buildTotalBreakdown(),
          ),
          const SizedBox(height: 16),
          _buildCard(
            title: 'Estimator\'s Note',
            child: TextField(
              maxLines: 4,
              decoration: const InputDecoration(
                hintText: 'Add a short note for this estimate...',
                border: OutlineInputBorder(),
              ),
              onChanged: (v) => setState(() => currentProject.note = v),
              controller: TextEditingController(text: currentProject.note),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _copyResults,
                  icon: const Icon(Icons.copy),
                  label: const Text('Copy'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF3B82F6),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _exportTxt,
                  icon: const Icon(Icons.download),
                  label: const Text('Export'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _shareResults,
                  icon: const Icon(Icons.share),
                  label: const Text('Share'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 100),
        ],
      ),
    );
  }

  Widget _buildSavedTab() {
    if (savedProjects.isEmpty) {
      return const Center(
        child: Text('No saved projects yet', style: TextStyle(color: Colors.grey)),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: savedProjects.length,
      itemBuilder: (context, index) {
        final project = savedProjects[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            title: Text(project.clientName.isEmpty ? 'Project ${index + 1}' : project.clientName,
                style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('${project.projectAddress} • ${project.rooms.length} room(s)'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  onPressed: () => _loadProject(project),
                  icon: const Icon(Icons.folder_open, color: Color(0xFF6A3AF2)),
                ),
                IconButton(
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Delete Project?'),
                        content: const Text('This action cannot be undone.'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
                          TextButton(
                            onPressed: () {
                              _deleteProject(project.id);
                              Navigator.pop(ctx);
                            },
                            child: const Text('Delete', style: TextStyle(color: Colors.red)),
                          ),
                        ],
                      ),
                    );
                  },
                  icon: const Icon(Icons.delete, color: Colors.red),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildRoomCard(Room room) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ExpansionTile(
        title: Text(room.name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('Area: ${_calculateRoomArea(room).toStringAsFixed(1)} ft²'),
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                _buildTextField(
                  label: 'Room Name',
                  value: room.name,
                  onChanged: (v) => setState(() => room.name = v),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _buildNumberField(
                        label: 'Length (ft)',
                        value: room.length?.toString() ?? '',
                        onChanged: (v) => setState(() => room.length = double.tryParse(v)),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildNumberField(
                        label: 'Width (ft)',
                        value: room.width?.toString() ?? '',
                        onChanged: (v) => setState(() => room.width = double.tryParse(v)),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildNumberField(
                        label: 'Height (ft)',
                        value: room.height?.toString() ?? '',
                        onChanged: (v) => setState(() => room.height = double.tryParse(v)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _buildNumberField(
                        label: 'Doors',
                        value: room.doors.toString(),
                        onChanged: (v) => setState(() => room.doors = int.tryParse(v) ?? 0),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildNumberField(
                        label: 'Windows',
                        value: room.windows.toString(),
                        onChanged: (v) => setState(() => room.windows = int.tryParse(v) ?? 0),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildNumberField(
                        label: 'Coats',
                        value: room.coats.toString(),
                        onChanged: (v) => setState(() => room.coats = int.tryParse(v) ?? 1),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (currentProject.rooms.length > 1)
                  ElevatedButton.icon(
                    onPressed: () {
                      setState(() {
                        currentProject.rooms.remove(room);
                      });
                    },
                    icon: const Icon(Icons.delete),
                    label: const Text('Delete Room'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red.shade50,
                      foregroundColor: Colors.red,
                      minimumSize: const Size(double.infinity, 44),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCard({String? title, IconData? icon, required Widget child}) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (title != null)
              Row(
                children: [
                  if (icon != null) Icon(icon, size: 18, color: const Color(0xFF6A3AF2)),
                  if (icon != null) const SizedBox(width: 8),
                  Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                ],
              ),
            if (title != null) const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }

  Widget _buildResultCard({
    required String title,
    required String mainText,
    required String summary,
    required Color color,
    required String details,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: color.withOpacity(0.3), width: 2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                    const SizedBox(height: 4),
                    Text(mainText, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                  ],
                ),
                if (summary.isNotEmpty)
                  Text(summary, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
              ],
            ),
            const SizedBox(height: 12),
            Text(details, style: TextStyle(color: Colors.grey.shade700, fontSize: 13)),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField({required String label, String? hint, required String value, required Function(String) onChanged}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
        const SizedBox(height: 4),
        TextField(
          decoration: InputDecoration(
            hintText: hint,
            border: const OutlineInputBorder(),
            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          ),
          onChanged: onChanged,
          controller: TextEditingController(text: value)..selection = TextSelection.collapsed(offset: value.length),
        ),
      ],
    );
  }

  Widget _buildNumberField({required String label, required String value, required Function(String) onChanged}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
        const SizedBox(height: 4),
        TextField(
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          ),
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          onChanged: onChanged,
          controller: TextEditingController(text: value)..selection = TextSelection.collapsed(offset: value.length),
        ),
      ],
    );
  }

  Widget _buildDropdown({
    required String label,
    required String value,
    required List<String> items,
    required Function(String?) onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
        const SizedBox(height: 4),
        DropdownButtonFormField<String>(
          value: value,
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          ),
          items: items.map((item) => DropdownMenuItem(value: item, child: Text(item))).toList(),
          onChanged: onChanged,
        ),
      ],
    );
  }

  Widget _buildActionButtons() {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.96),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 20, spreadRadius: 2),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildActionButton(Icons.save, 'Save', const Color(0xFF6A3AF2), _saveCurrentProject),
          _buildActionButton(Icons.calculate, 'Calc', const Color(0xFF3B82F6), _calculateEstimate),
          _buildActionButton(Icons.copy, 'Copy', const Color(0xFF10B981), _copyResults),
          _buildActionButton(Icons.share, 'Share', const Color(0xFF8B5CF6), _shareResults),
        ],
      ),
    );
  }

  Widget _buildActionButton(IconData icon, String label, Color color, VoidCallback onPressed) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 18),
            const SizedBox(height: 2),
            Text(label, style: const TextStyle(fontSize: 10)),
          ],
        ),
      ),
    );
  }

  double _calculateRoomArea(Room room) {
    final l = room.length ?? 0;
    final w = room.width ?? 0;
    final h = room.height ?? 0;
    final wallArea = 2 * (l + w) * h;
    final doorArea = room.doors * 21;
    final windowArea = room.windows * 15;
    return (wallArea - doorArea - windowArea).clamp(0, double.infinity);
  }

  String _buildTotalBreakdown() {
    String text = '';
    if (results!.paintCost != null) text += '• Paint: \$${results!.paintCost!.toStringAsFixed(2)}\n';
    if (results!.laborCost != null) text += '• Labor: \$${results!.laborCost!.toStringAsFixed(2)}\n';
    if (results!.totalCost != null) text += '• TOTAL: \$${results!.totalCost!.toStringAsFixed(2)}\n';
    text += '\nRooms:\n';
    for (var r in results!.rooms) {
      text += ' • ${r.name}: ${r.area.toStringAsFixed(1)} ft² — ${r.paint.toStringAsFixed(2)} gal (${r.coats} coats)\n';
    }
    if (currentProject.note.isNotEmpty) {
      text += '\nEstimator\'s Note:\n${currentProject.note}\n';
    }
    return text;
  }

  Future<void> _copyResults() async {
    if (results == null) return;
    final text = _buildResultsText();
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✓ Results copied to clipboard')),
      );
    }
  }

  Future<void> _shareResults() async {
    if (results == null) return;
    final text = _buildResultsText();
    await Share.share(text, subject: currentProject.clientName.isEmpty ? 'Paint Estimate' : currentProject.clientName);
  }

  Future<void> _exportTxt() async {
    if (results == null) return;
    try {
      final text = _buildResultsText();
      final directory = await getApplicationDocumentsDirectory();
      final filename = '${currentProject.clientName.replaceAll(' ', '_')}_estimate.txt';
      final file = File('${directory.path}/$filename');
      await file.writeAsString(text);
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('✓ Exported to ${file.path}')),
        );
      }
      
      // Also share the file
      await Share.shareXFiles([XFile(file.path)], text: 'Paint Estimate');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error exporting: $e')),
        );
      }
    }
  }

  String _buildResultsText() {
    String text = 'OLE GLORY PAINTPRO — Estimate\n';
    if (currentProject.clientName.isNotEmpty) text += 'Client: ${currentProject.clientName}\n';
    if (currentProject.projectAddress.isNotEmpty) text += 'Address: ${currentProject.projectAddress}\n';
    text += '\nTotal Area: ${results!.totalArea.toStringAsFixed(1)} sq ft\n';
    text += 'Paint Needed: ${results!.totalPaint.toStringAsFixed(2)} gal (≈ ${results!.gallons} gal / ${results!.quarts} qts / ${results!.liters.toStringAsFixed(2)} L)\n';
    if (results!.paintCost != null) text += 'Paint Cost: \$${results!.paintCost!.toStringAsFixed(2)}\n';
    text += 'Labor Hours: ${results!.laborHours.toStringAsFixed(1)} hrs\n';
    if (results!.laborCost != null) text += 'Labor Cost: \$${results!.laborCost!.toStringAsFixed(2)}\n';
    if (results!.totalCost != null) text += 'TOTAL: \$${results!.totalCost!.toStringAsFixed(2)}\n';
    text += '\nRooms:\n';
    for (var r in results!.rooms) {
      text += ' • ${r.name}: ${r.area.toStringAsFixed(1)} ft² — ${r.paint.toStringAsFixed(2)} gal (${r.coats} coats)\n';
    }
    if (currentProject.note.isNotEmpty) {
      text += '\nEstimator\'s Note:\n${currentProject.note}\n';
    }
    return text;
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
}

// Models
class Project {
  String id;
  String clientName;
  String projectAddress;
  List<Room> rooms;
  double coverage;
  double? paintPrice;
  double? laborRate;
  double? pricePerSqFt;
  String surfaceType;
  String note;

  Project({
    required this.id,
    this.clientName = '',
    this.projectAddress = '',
    required this.rooms,
    this.coverage = 350,
    this.paintPrice,
    this.laborRate,
    this.pricePerSqFt,
    this.surfaceType = 'smooth',
    this.note = '',
  });

  static Project newProject() {
    return Project(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      rooms: [Room(id: '1', name: 'Living Room')],
    );
  }

  void addRoom() {
    rooms.add(Room(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: 'Room ${rooms.length + 1}',
    ));
  }

  Project copy() {
    return Project(
      id: id,
      clientName: clientName,
      projectAddress: projectAddress,
      rooms: rooms.map((r) => r.copy()).toList(),
      coverage: coverage,
      paintPrice: paintPrice,
      laborRate: laborRate,
      pricePerSqFt: pricePerSqFt,
      surfaceType: surfaceType,
      note: note,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'clientName': clientName,
        'projectAddress': projectAddress,
        'rooms': rooms.map((r) => r.toJson()).toList(),
        'coverage': coverage,
        'paintPrice': paintPrice,
        'laborRate': laborRate,
        'pricePerSqFt': pricePerSqFt,
        'surfaceType': surfaceType,
        'note': note,
      };

  factory Project.fromJson(Map<String, dynamic> json) => Project(
        id: json['id'],
        clientName: json['clientName'] ?? '',
        projectAddress: json['projectAddress'] ?? '',
        rooms: (json['rooms'] as List).map((r) => Room.fromJson(r)).toList(),
        coverage: json['coverage'] ?? 350,
        paintPrice: json['paintPrice'],
        laborRate: json['laborRate'],
        pricePerSqFt: json['pricePerSqFt'],
        surfaceType: json['surfaceType'] ?? 'smooth',
        note: json['note'] ?? '',
      );
}

class Room {
  String id;
  String name;
  double? length;
  double? width;
  double? height;
  int doors;
  int windows;
  int coats;

  Room({
    required this.id,
    this.name = 'Room',
    this.length,
    this.width,
    this.height,
    this.doors = 1,
    this.windows = 2,
    this.coats = 2,
  });

  Room copy() => Room(
        id: id,
        name: name,
        length: length,
        width: width,
        height: height,
        doors: doors,
        windows: windows,
        coats: coats,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'length': length,
        'width': width,
        'height': height,
        'doors': doors,
        'windows': windows,
        'coats': coats,
      };

  factory Room.fromJson(Map<String, dynamic> json) => Room(
        id: json['id'],
        name: json['name'] ?? 'Room',
        length: json['length'],
        width: json['width'],
        height: json['height'],
        doors: json['doors'] ?? 1,
        windows: json['windows'] ?? 2,
        coats: json['coats'] ?? 2,
      );
}

class RoomResult {
  final String name;
  final double area;
  final double paint;
  final int coats;

  RoomResult({required this.name, required this.area, required this.paint, required this.coats});
}

class CalculationResults {
  final List<RoomResult> rooms;
  final double totalArea;
  final double totalPaint;
  final int gallons;
  final int quarts;
  final double liters;
  final double? paintCost;
  final double laborHours;
  final double? laborCost;
  final double? totalCost;

  CalculationResults({
    required this.rooms,
    required this.totalArea,
    required this.totalPaint,
    required this.gallons,
    required this.quarts,
    required this.liters,
    this.paintCost,
    required this.laborHours,
    this.laborCost,
    this.totalCost,
  });
}

// Calculator
class Calculator {
  static const Map<String, double> surfaceMultipliers = {
    'smooth': 1.0,
    'semi-smooth': 1.1,
    'textured': 1.15,
    'rough': 1.25,
  };

  static CalculationResults calculate(Project project) {
    final surfaceMultiplier = surfaceMultipliers[project.surfaceType] ?? 1.0;
    final adjustedCoverage = project.coverage / surfaceMultiplier;

    double totalArea = 0;
    double totalPaintNeeded = 0;
    List<RoomResult> roomResults = [];

    for (var room in project.rooms) {
      final l = room.length ?? 0;
      final w = room.width ?? 0;
      final h = room.height ?? 0;
      final wallArea = 2 * (l + w) * h;
      final doorArea = room.doors * 21;
      final windowArea = room.windows * 15;
      final paintable = (wallArea - doorArea - windowArea).clamp(0, double.infinity);
      final paintNeeded = (paintable * room.coats) / adjustedCoverage;

      roomResults.add(RoomResult(name: room.name, area: paintable, paint: paintNeeded, coats: room.coats));
      totalArea += paintable;
      totalPaintNeeded += paintNeeded;
    }

    final gallons = totalPaintNeeded.ceil();
    final quarts = (totalPaintNeeded * 4).ceil();
    final liters = totalPaintNeeded * 3.78541;

    final paintCost = project.paintPrice != null ? gallons * project.paintPrice! : null;
    final laborHours = (totalArea / project.coverage) * 8;
    final laborCost = project.laborRate != null ? laborHours * project.laborRate! : null;

    double? totalCost;
    if (project.pricePerSqFt != null) {
      totalCost = totalArea * project.pricePerSqFt!;
    } else if (paintCost != null && laborCost != null) {
      totalCost = paintCost + laborCost;
    } else if (paintCost != null) {
      totalCost = paintCost;
    } else if (laborCost != null) {
      totalCost = laborCost;
    }

    return CalculationResults(
      rooms: roomResults,
      totalArea: totalArea,
      totalPaint: totalPaintNeeded,
      gallons: gallons,
      quarts: quarts,
      liters: liters,
      paintCost: paintCost,
      laborHours: laborHours,
      laborCost: laborCost,
      totalCost: totalCost,
    );
  }
}
