#!/bin/bash

echo "======================================"
echo "Ole Glory PaintPro - APK Builder"
echo "======================================"
echo ""

# Check if Flutter is installed
if ! command -v flutter &> /dev/null
then
    echo "❌ Flutter is not installed or not in PATH"
    echo ""
    echo "Please install Flutter first:"
    echo "https://docs.flutter.dev/get-started/install"
    echo ""
    exit 1
fi

echo "✅ Flutter found: $(flutter --version | head -n 1)"
echo ""

# Check Flutter setup
echo "📋 Running Flutter doctor..."
flutter doctor
echo ""

# Clean previous builds
echo "🧹 Cleaning previous builds..."
flutter clean
echo ""

# Get dependencies
echo "📦 Installing dependencies..."
flutter pub get
echo ""

# Build release APK
echo "🔨 Building release APK..."
echo "⏳ This will take 3-5 minutes..."
echo ""
flutter build apk --release

# Check if build succeeded
if [ $? -eq 0 ]; then
    echo ""
    echo "======================================"
    echo "✅ BUILD SUCCESSFUL!"
    echo "======================================"
    echo ""
    echo "📱 Your APK is ready at:"
    echo "   build/app/outputs/flutter-apk/app-release.apk"
    echo ""
    echo "📊 File info:"
    ls -lh build/app/outputs/flutter-apk/app-release.apk
    echo ""
    echo "🚀 Next steps:"
    echo "   1. Copy APK to your Android device"
    echo "   2. Enable 'Install from unknown sources'"
    echo "   3. Tap the APK file to install"
    echo ""
    echo "   OR install via USB:"
    echo "   adb install build/app/outputs/flutter-apk/app-release.apk"
    echo ""
else
    echo ""
    echo "======================================"
    echo "❌ BUILD FAILED"
    echo "======================================"
    echo ""
    echo "Common fixes:"
    echo "   1. Run: flutter doctor"
    echo "   2. Accept licenses: flutter doctor --android-licenses"
    echo "   3. Update Flutter: flutter upgrade"
    echo ""
    exit 1
fi
