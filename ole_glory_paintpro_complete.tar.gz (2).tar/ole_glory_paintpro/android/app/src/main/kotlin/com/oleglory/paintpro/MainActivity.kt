package com.oleglory.paintpro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
